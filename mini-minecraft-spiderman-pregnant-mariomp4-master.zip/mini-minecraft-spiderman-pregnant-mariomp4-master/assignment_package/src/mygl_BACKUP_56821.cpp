#include "mygl.h"
#include <glm_includes.h>
#include "scene/player.h"
#include <iostream>
#include <QApplication>
#include <QKeyEvent>
#include <qdatetime.h>
#include <glm/glm.hpp>



FrameBuffer::FrameBuffer(OpenGLContext *context,
                         unsigned int width, unsigned int height, unsigned int devicePixelRatio)
    : mp_context(context), m_frameBuffer(-1),
    m_outputTexture(-1), m_depthRenderBuffer(-1),
    m_width(width), m_height(height), m_devicePixelRatio(devicePixelRatio), m_created(false)
{}

void FrameBuffer::resize(unsigned int width, unsigned int height, unsigned int devicePixelRatio) {
    m_width = width;
    m_height = height;
    m_devicePixelRatio = devicePixelRatio;
}

void FrameBuffer::create() {
    // Initialize the frame buffers and render textures
    mp_context->glGenFramebuffers(1, &m_frameBuffer);
    mp_context->glGenTextures(1, &m_outputTexture);
    mp_context->glGenRenderbuffers(1, &m_depthRenderBuffer);

    mp_context->glBindFramebuffer(GL_FRAMEBUFFER, m_frameBuffer);
    // Bind our texture so that all functions that deal with textures will interact with this one
    mp_context->glBindTexture(GL_TEXTURE_2D, m_outputTexture);
    // Give an empty image to OpenGL ( the last "0" )
    mp_context->glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, m_width * m_devicePixelRatio, m_height * m_devicePixelRatio, 0, GL_RGB, GL_UNSIGNED_BYTE, (void*)0);

    // Set the render settings for the texture we've just created.
    // Essentially zero filtering on the "texture" so it appears exactly as rendered
    mp_context->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    mp_context->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    // Clamp the colors at the edge of our texture
    mp_context->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    mp_context->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    // Initialize our depth buffer
    mp_context->glBindRenderbuffer(GL_RENDERBUFFER, m_depthRenderBuffer);
    mp_context->glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT, m_width  * m_devicePixelRatio, m_height * m_devicePixelRatio);
    mp_context->glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, m_depthRenderBuffer);

    // Set m_renderedTexture as the color output of our frame buffer
    mp_context->glFramebufferTexture(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, m_outputTexture, 0);

    // Sets the color output of the fragment shader to be stored in GL_COLOR_ATTACHMENT0,
    // which we previously set to m_renderedTexture
    GLenum drawBuffers[1] = {GL_COLOR_ATTACHMENT0};
    mp_context->glDrawBuffers(1, drawBuffers); // "1" is the size of drawBuffers

    m_created = true;
    if(mp_context->glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    {
        m_created = false;
        std::cout << "Frame buffer did not initialize correctly..." << std::endl;
        mp_context->printGLErrorLog();
    }
}

void FrameBuffer::createDepth() {
    // Initialize the frame buffers and render textures
    mp_context->glGenFramebuffers(1, &m_frameBuffer);
    mp_context->glGenTextures(1, &m_outputTexture);

    mp_context->glBindFramebuffer(GL_FRAMEBUFFER, m_frameBuffer);
    // Bind our texture so that all functions that deal with textures will interact with this one
    mp_context->glBindTexture(GL_TEXTURE_2D, m_outputTexture);
    // Give an empty image to OpenGL ( the last "0" )
    mp_context->glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT16, m_width * m_devicePixelRatio, m_height * m_devicePixelRatio, 0, GL_DEPTH_COMPONENT, GL_FLOAT, 0);

    // Set the render settings for the texture we've just created.
    // Essentially zero filtering on the "texture" so it appears exactly as rendered
    mp_context->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    mp_context->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    // Clamp the colors at the edge of our texture
    mp_context->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    mp_context->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    // Set m_renderedTexture as the color output of our frame buffer
    mp_context->glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, m_outputTexture, 0);


    m_created = true;
    if(mp_context->glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    {
        m_created = false;
        std::cout << "Frame buffer did not initialize correctly..." << std::endl;
        mp_context->printGLErrorLog();
    }
}

void FrameBuffer::destroy() {
    if(m_created) {
        m_created = false;
        mp_context->glDeleteFramebuffers(1, &m_frameBuffer);
        mp_context->glDeleteTextures(1, &m_outputTexture);
        mp_context->glDeleteRenderbuffers(1, &m_depthRenderBuffer);
    }
}

void FrameBuffer::bindFrameBuffer() {
    mp_context->glBindFramebuffer(GL_FRAMEBUFFER, m_frameBuffer);
}

void FrameBuffer::bindToTextureSlot(unsigned int slot) {
    m_textureSlot = slot;
    mp_context->glActiveTexture(GL_TEXTURE0 + slot);
    mp_context->glBindTexture(GL_TEXTURE_2D, m_outputTexture);
}

unsigned int FrameBuffer::getTextureSlot() const {
    return m_textureSlot;

}

MyGL::MyGL(QWidget *parent)
    : OpenGLContext(parent),

    m_worldAxes(this), m_progLambert(this), m_progFlat(this), m_progInstanced(this),
    m_progLiquid(this), m_progSky(this), m_terrain(this), m_player(glm::vec3(48.f, 130.f, 48.f), m_terrain),

    m_changeInTime(QDateTime::currentMSecsSinceEpoch()), m_frameBuffer(this, this->width(), this->height(), this->devicePixelRatio()), m_postProcessNothing(this),
    m_postProcessWater(this), m_postProcessLava(this), m_geomQuad(this), m_texture(this), walkingsound(this), m_time(0)


{
    // Connect the timer to a function so that when the timer ticks the function is executed
    connect(&m_timer, SIGNAL(timeout()), this, SLOT(tick()));
    // Tell the timer to redraw 60 times per second
    m_timer.start(16);
    setFocusPolicy(Qt::ClickFocus);

    setMouseTracking(true); // MyGL will track the mouse's movements even if a mouse button is not pressed
    setCursor(Qt::BlankCursor); // Make the cursor invisible

}

MyGL::~MyGL() {
    makeCurrent();
    glDeleteVertexArrays(1, &vao);
}


void MyGL::moveMouseToCenter() {
    QCursor::setPos(this->mapToGlobal(QPoint(width() / 2, height() / 2)));
}

void MyGL::initializeGL()
{
    // Create an OpenGL context using Qt's QOpenGLFunctions_3_2_Core class
    // If you were programming in a non-Qt context you might use GLEW (GL Extension Wrangler)instead
    initializeOpenGLFunctions();
    // Print out some information about the current OpenGL context
    debugContextVersion();

    // Set a few settings/modes in OpenGL rendering
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    // Set the color with which the screen is filled at the start of each render call.
    glClearColor(0.37f, 0.74f, 1.0f, 1);

    printGLErrorLog();

    // Create a Vertex Attribute Object
    glGenVertexArrays(1, &vao);

    // Initialize render buffers
    m_frameBuffer.resize(this->width(), this->height(), this->devicePixelRatio());
    m_frameBuffer.create();

    //Create the instance of the world axes
    m_worldAxes.createVBOdata();

    //Create instance of quad
    m_geomQuad.createVBOdata();

    // Create and set up the diffuse shader
    m_progLambert.create(":/glsl/lambert.vert.glsl", ":/glsl/lambert.frag.glsl");
    // Create and set up the flat lighting shader
    m_progFlat.create(":/glsl/flat.vert.glsl", ":/glsl/flat.frag.glsl");
    m_progLiquid.create(":/glsl/liquid.vert.glsl", ":/glsl/liquid.frag.glsl");
    m_progInstanced.create(":/glsl/instanced.vert.glsl", ":/glsl/lambert.frag.glsl");
    m_progSky.create(":/glsl/sky.vert.glsl", ":/glsl/sky.frag.glsl");
    m_geomQuad.createVBOdata();
        // Create and set up post process shaders
    m_postProcessNothing.create(":/glsl/postprocess.vert.glsl", ":/glsl/nothing.frag.glsl");
    m_postProcessWater.create(":/glsl/postprocess.vert.glsl", ":/glsl/water.frag.glsl");
    m_postProcessLava.create(":/glsl/postprocess.vert.glsl", ":/glsl/lava.frag.glsl");

    // Set a color with which to draw geometry.
    // This will ultimately not be used when you change
    // your program to render Chunks with vertex colors
    // and UV coordinates
    m_progLambert.setGeometryColor(glm::vec4(0,1,0,1));
    m_progLiquid.setGeometryColor(glm::vec4(0,1,0,1));

    // We have to have a VAO bound in OpenGL 3.2 Core. But if we're not
    // using multiple VAOs, we can just bind one once.
    glBindVertexArray(vao);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_texture.create(":/textures/minecraft_textures_all.png", 2);

    //m_terrain.createTestScene();

    walkingsound.setSource(QUrl::fromLocalFile(":/sounds/walking.wav"));
    walkingsound.setVolume(0.9f);

    //sounds

    walkingsound.setSource(QUrl::fromLocalFile(":/sounds/walking.wav"));
    walkingsound.setVolume(0.7f);

    flyingsound.setSource(QUrl::fromLocalFile(":/sounds/airwoosh.wav"));
    flyingsound.setVolume(1.f);

}

void MyGL::resizeGL(int w, int h) {
    m_postProcessNothing.setDimensions(glm::ivec2(w, h));
    m_postProcessWater.setDimensions(glm::ivec2(w, h));
    m_postProcessLava.setDimensions(glm::ivec2(w, h));
    m_progSky.setDimensions(glm::ivec2(w, h));
    m_progLambert.setDimensions(glm::ivec2(w, h));
    m_progLiquid.setDimensions(glm::ivec2(w, h));

    m_frameBuffer.resize(w, h, this->devicePixelRatio());
    glViewport(0,0,this->width() * this->devicePixelRatio(), this->height() * this->devicePixelRatio());

    //This code sets the concatenated view and perspective projection matrices used for
    //our scene's camera view.
    m_player.setCameraWidthHeight(static_cast<unsigned int>(w), static_cast<unsigned int>(h));
    glm::mat4 viewproj = m_player.mcr_camera.getViewProj();

    // Upload the view-projection matrix to our shaders (i.e. onto the graphics card)

    m_progLambert.setViewProjMatrix(viewproj);
    m_progLiquid.setViewProjMatrix(viewproj);
    m_progFlat.setViewProjMatrix(viewproj);
    m_progSky.setViewProjMatrix(glm::inverse(viewproj));

    m_progInstanced.setViewProjMatrix(viewproj);

    printGLErrorLog();
}


// MyGL's constructor links tick() to a timer that fires 60 times per second.
// We're treating MyGL as our game engine class, so we're going to perform
// all per-frame actions here, such as performing physics updates on all
// entities in the scene.
void MyGL::tick() {
    m_progLambert.setCamPos(m_player.mcr_camera.mcr_position);
    m_progLiquid.setCamPos(m_player.mcr_camera.mcr_position);
    m_progSky.setCamPos(m_player.mcr_camera.mcr_position);

    float dT = (QDateTime::currentMSecsSinceEpoch() - m_changeInTime) / 1000.f;
    dT = glm::min(dT, 1.f);
    if (!m_player.playerPosInitialized && m_terrain.hasChunkAt((int) m_player.mcr_camera.mcr_position.x, (int) m_player.mcr_camera.mcr_position.z)) {
        Chunk* c = m_terrain.getChunkAt((int) m_player.mcr_camera.mcr_position.x, (int) m_player.mcr_camera.mcr_position.z).get();
        if (c != nullptr && c->vboSet) {
            m_player.moveUpGlobal(c->getHeightAt((int) m_player.mcr_position.x % 16, (int) m_player.mcr_position.z % 16) - m_player.mcr_camera.mcr_position.y + 2.5);
            m_player.playerPosInitialized = true;
        }
    }

    m_player.tick(dT, m_inputs);
    m_changeInTime = QDateTime::currentMSecsSinceEpoch();

    m_progLambert.setTime(m_time);
    m_progLiquid.setTime(m_time);
    m_progSky.setTime(m_time);
    m_postProcessWater.setTime(m_time);
    m_postProcessLava.setTime(m_time);
    m_time++;

    m_terrain.updateScene(m_player.mcr_position); // as player moves update scene for terrain expansion

    update(); // Calls paintGL() as part of a larger QOpenGLWidget pipeline
    sendPlayerDataToGUI(); // Updates the info in the secondary window displaying player data
}

void MyGL::sendPlayerDataToGUI() const {
    emit sig_sendPlayerPos(m_player.posAsQString());
    emit sig_sendPlayerVel(m_player.velAsQString());
    emit sig_sendPlayerAcc(m_player.accAsQString());
    emit sig_sendPlayerLook(m_player.lookAsQString());
    glm::vec2 pPos(m_player.mcr_position.x, m_player.mcr_position.z);
    glm::ivec2 chunk(16 * glm::ivec2(glm::floor(pPos / 16.f)));
    glm::ivec2 zone(64 * glm::ivec2(glm::floor(pPos / 64.f)));
    emit sig_sendPlayerChunk(QString::fromStdString("( " + std::to_string(chunk.x) + ", " + std::to_string(chunk.y) + " )"));
    emit sig_sendPlayerTerrainZone(QString::fromStdString("( " + std::to_string(zone.x) + ", " + std::to_string(zone.y) + " )"));
}

// This function is called whenever update() is called.
// MyGL's constructor links update() to a timer that fires 60 times per second,
// so paintGL() called at a rate of 60 frames per second.
void MyGL::paintGL() {
    m_frameBuffer.bindFrameBuffer();
    glViewport(0,0, this->width() * this->devicePixelRatio(), this->height() * this->devicePixelRatio());

    // Clear the screen so that we only see newly drawn images
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    m_progFlat.setViewProjMatrix(m_player.mcr_camera.getViewProj());
    m_progLambert.setViewProjMatrix(m_player.mcr_camera.getViewProj());
    m_progLambert.setModelMatrix(glm::mat4());
    m_progLiquid.setViewProjMatrix(m_player.mcr_camera.getViewProj());
    m_progLiquid.setModelMatrix(glm::mat4());
    m_progSky.setViewProjMatrix(glm::inverse(m_player.mcr_camera.getViewProj()));
    m_progSky.draw(m_geomQuad);

    m_texture.bind(2); // Minecraft block texture in slot 2
    renderTerrain(); //creates VBO data for chunks
    renderTransparent();

    glDisable(GL_DEPTH_TEST);
    m_progFlat.setModelMatrix(glm::mat4());
    m_progFlat.setViewProjMatrix(m_player.mcr_camera.getViewProj());
    m_progFlat.draw(m_worldAxes);
    glEnable(GL_DEPTH_TEST);

    performPostProcessRenderPass();
}

void MyGL::performPostProcessRenderPass()
{
    // Render the frame buffer as a texture on a screen-size quad

    // Tell OpenGL to render to the viewport's frame buffer
    glBindFramebuffer(GL_FRAMEBUFFER, this->defaultFramebufferObject());
    // Render on the whole framebuffer, complete from the lower left corner to the upper right
    glViewport(0,0,this->width() * this->devicePixelRatio(), this->height() * this->devicePixelRatio());
    // Clear the screen
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // Bind our texture in Texture Unit 0
    m_frameBuffer.bindToTextureSlot(0);

    glm::vec3 camPos = m_player.mcr_camera.mcr_position;
    if (m_terrain.hasChunkAt(camPos.x, camPos.z) && m_terrain.getBlockAt(camPos) == WATER) {
        m_postProcessWater.draw(m_geomQuad, 0);
    } else if (m_terrain.hasChunkAt(camPos.x, camPos.z) && m_terrain.getBlockAt(camPos) == LAVA) {
        m_postProcessLava.draw(m_geomQuad,0);
    } else {
        m_postProcessNothing.draw(m_geomQuad,0);
    }
}

// TODO: Change this so it renders the nine zones of generated
// terrain that surround the player (refer to Terrain::m_generatedTerrain
// for more info)
void MyGL::renderTerrain() {
    glm::vec3 p = m_player.mcr_position;

    int renderDist = 16 * 20;

    for (int x = p.x - (renderDist / 2); x < p.x + (renderDist / 2); x += 16) {
        for (int z = p.z - (renderDist / 2); z < p.z + (renderDist / 2); z += 16) {
            if (m_terrain.hasChunkAt(x, z)) {
                m_terrain.drawOpq(m_terrain.getChunkAt(x, z).get(), &m_progLambert);
            }
        }
    }
}

void MyGL::renderTransparent() {
    glm::vec3 p = m_player.mcr_position;

    int renderDist = 16 * 20;

    for (int x = p.x - (renderDist / 2); x < p.x + (renderDist / 2); x += 16) {
        for (int z = p.z - (renderDist / 2); z < p.z + (renderDist / 2); z += 16) {
            if (m_terrain.hasChunkAt(x, z)) {
                m_terrain.drawTrans(m_terrain.getChunkAt(x, z).get(), &m_progLiquid);

            }
        }
    }
}


void MyGL::keyPressEvent(QKeyEvent *e) {
    float amount = 2.0f;
    if(e->modifiers() & Qt::ShiftModifier){
        amount = 10.0f;
    }

    if (!e->isAutoRepeat()) {
        if (e->key() == Qt::Key_Escape) {
            QApplication::quit();
        }
        else if (e->key() == Qt::Key_W) {
            m_inputs.wPressed = true;
            walkingsound.play();


            if (m_inputs.inflightMode) {
                flyingsound.play();
            }


        }
        else if (e->key() == Qt::Key_S) {
            m_inputs.sPressed = true;
            walkingsound.play();


            if (m_inputs.inflightMode) {
                flyingsound.play();
            }


        }
        else if (e->key() == Qt::Key_D) {
            m_inputs.dPressed = true;
            walkingsound.play();


            if (m_inputs.inflightMode) {
                flyingsound.play();
            }


        }
        else if (e->key() == Qt::Key_A) {
            m_inputs.aPressed = true;
            walkingsound.play();


            if (m_inputs.inflightMode) {
                flyingsound.play();
            }


        }

        else if (e->key() == Qt::Key_F) {
            m_inputs.inflightMode = !m_inputs.inflightMode;
            if (m_inputs.inflightMode) {
                std::cout << "flight mode ACTIVATED >:)" << std::endl;
                walkingsound.stop();
                flyingsound.play();
            }
            else {
                std::cout << "flight mode DEACTIVATED" << std::endl;
                //flyingsound.stop();
            }
        }

        if (m_inputs.inflightMode){
            walkingsound.stop();


            flyingsound.play();


            if (e->key() == Qt::Key_Q) {
                m_inputs.qPressed = true;
                flyingsound.play();
            } else if (e->key() == Qt::Key_E) {
                m_inputs.ePressed = true;
                flyingsound.play();
            }
        } else {
            flyingsound.stop();
            if (e->key() == Qt::Key_Space) {
                m_inputs.spacePressed = true;
            }
        }
    }

#ifdef __APPLE__
    if(e->key() == Qt::Key_Up) {
        m_player.rotateOnRightLocal(-5);
    }
    else if(e->key() == Qt::Key_Down) {
        m_player.rotateOnRightLocal(5);
    }
    else if(e->key() == Qt::Key_Right) {
        m_player.rotateOnUpGlobal(-5);
    }
    else if(e->key() == Qt::Key_Left) {
        m_player.rotateOnUpGlobal(5);
    }
#endif
}
void MyGL::keyReleaseEvent(QKeyEvent *e) {
    if (!e->isAutoRepeat()) {
        if (e->key() == Qt::Key_W) {
            m_inputs.wPressed = false;
            walkingsound.stop();
        } else if (e->key() == Qt::Key_S) {
            m_inputs.sPressed = false;
            walkingsound.stop();
        } else if (e->key() == Qt::Key_D) {
            m_inputs.dPressed = false;
            walkingsound.stop();
        } else if (e->key() == Qt::Key_A) {
            m_inputs.aPressed = false;
            walkingsound.stop();
        } else if (e->key() == Qt::Key_Q) {
            m_inputs.qPressed = false;
            flyingsound.stop();
        } else if (e->key() == Qt::Key_E) {
            m_inputs.ePressed = false;
            flyingsound.stop();
        } else if (e->key() == Qt::Key_Space) {
            m_inputs.spacePressed = false;
        }
    }
}

void MyGL::mouseMoveEvent(QMouseEvent *e) {
#ifndef __APPLE__
    // TODO
    const float sens = 50.0;

    float dx = width() * 0.5 - e->pos().x();
    if (dx != 0) {
        m_player.rotateOnUpGlobal(dx/width() * sens);
    }

    float dy = height() * 0.5 - e->pos().y() - 0.5;
    if (dy != 0) {
        m_player.rotateOnRightLocal(dy/height() * sens);
    }

    moveMouseToCenter();
#endif
}

void MyGL::mousePressEvent(QMouseEvent *e) {
    // TODO
    //want to enable the player to remove the block currently overlapping the center of the
    //screen when the left mouse button is pressed, provided that block is within 3 units of distance from the camera
    if (e->button() == Qt::LeftButton) {
        m_player.removeblock(&m_terrain);

    }

    else if (e->button() == Qt::RightButton) {
        m_player.addBlock(&m_terrain, STONE);

    }
}

// 1. bind custom FrameBuffer, set viewport size, clear frame buffer
// 2. draw 3d geometry
// 3. bind qt's defaultFrameBufferObject, set viewport size, clear frame buffer
// 4. call framebuffer::bindToTextureSlot with whatever slot you want
// 5. gluniformli() to set your post process shader's sampler2D to the texture
// 6.
// look at homework 4: modify noOp.frag and passthrough.vert
