#ifndef VBOWORKER_H
#define VBOWORKER_H

#include <QRunnable>
#include <glm/glm.hpp>
#include "chunk.h"
#include <QMutexLocker>
#include "texture.h"
//#include "terrain.h"


class Chunk;

struct VBOData {
    std::vector<GLuint> opqIdx;
    std::vector<GLuint> trnsIdx;
    std::vector<glm::vec4> opqAttrs;
    std::vector<glm::vec4> trnsAttrs;

    void clear() {
        opqIdx.clear();
        trnsIdx.clear();
        opqAttrs.clear();
        trnsAttrs.clear();
    }

};

class VBOWorker : public QRunnable
{

public:

    VBOWorker(Chunk* c, std::vector<Chunk*>& toPush, QMutex& pushLock);
    void run() override;
private:
    std::unique_ptr<VBOData> data;
    Chunk* c;
    std::vector<Chunk*>& toPush;
    QMutex& pushLock;
};

#endif // VBOWORKER_H
