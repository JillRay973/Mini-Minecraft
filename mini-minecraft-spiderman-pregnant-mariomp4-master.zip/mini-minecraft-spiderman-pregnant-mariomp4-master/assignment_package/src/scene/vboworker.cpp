#include "vboworker.h"
#include <QMutexLocker>
#include <iostream>
#include "terrain.h"
#include "chunk.h"


VBOWorker::VBOWorker(Chunk* c, std::vector<Chunk*>& toPush, QMutex& pushLock) :
    c(c), data(std::make_unique<VBOData>()), toPush(toPush), pushLock(pushLock) {
    //    std::cout << "Making vbo worker " << c->id << " from thread " << this << std::endl;

}

void VBOWorker::run() {
    try {
        c->generateVBOData(data.get());

        c->vboMutex.lock();
        c->vTemp = std::move(data);
        c->vboMutex.unlock();
        pushLock.lock();
        toPush.push_back(c);
        pushLock.unlock();
    } catch (const std::exception &exc) {
        // catch anything thrown within try block that derives from std::exception
        std::cerr << "Error in BlockTypeWorker: " << exc.what() << std::endl;
    }
}
