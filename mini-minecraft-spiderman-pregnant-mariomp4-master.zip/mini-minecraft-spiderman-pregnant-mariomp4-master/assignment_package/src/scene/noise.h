#ifndef NOISE_H
#define NOISE_H
#include <glm/glm.hpp>

class Noise
{
public:
    Noise();
    static float noise1d(float a, float b);
    static float interpNoise2D(float x, float y);
    static float fbm(float x, float y, float H, float freq, float a);
    static float mix(float a, float b, float val);
    static float domainWarpFbm(float x, float y, float H, float freq, float a);
    static float perlinNoise2D(glm::vec2 uv);
    static float perlinNoise3D(glm::vec3 p, bool noise);
    static float surflet2D(glm::vec2 P, glm::vec2 gridPoint);
    static float surflet3D(glm::vec3 P, glm::vec3 gridPoint, bool noise);
    static glm::vec2 noise2d(glm::vec2 p);
    static glm::vec3 noise3d(glm::vec3 p);
    static glm::vec3 noise3d2(glm::vec3 p);

    static glm::vec2 noise2dv2(glm::vec2 p);
    static float noisev2(glm::vec2 p);
    static float perlin2dv2(glm::vec2 &p);
    static float fbm2(float x);
    static float interpNoise1D(float x);
    static float noise1d2(float a);

};

#endif // NOISE_H
