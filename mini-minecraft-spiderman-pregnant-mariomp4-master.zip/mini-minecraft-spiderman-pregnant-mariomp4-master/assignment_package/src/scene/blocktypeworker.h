#ifndef BLOCKTYPEWORKER_H
#define BLOCKTYPEWORKER_H

#include <QRunnable>
#include "chunk.h"
#include <unordered_set>

enum Continent : unsigned char
{
    OCEAN, COAST, NEAR_INLAND, MID_INLAND, FAR_INLAND
};

class Chunk;

static int ids = 0;

class BlockTypeWorker : public QRunnable
{
    friend class Chunk;
public:

    BlockTypeWorker(Chunk* c, std::unordered_set<Chunk*>& toVbo, QMutex& vboLock);
    void run() override;
private:
    Chunk* c;
    QMutex& vboLock;
    std::unordered_set<Chunk*>& toVbo;
    int id;

    void generateTree(int i, int j, int k);
    void generateBirchTree(int i, int j, int k);
    void generateSnowTree(int i, int j, int k);
    void generateCactus(int i, int j, int k);
    void generateIcicle(int i, int j, int k);
};

#endif // BLOCKTYPEWORKER_H
