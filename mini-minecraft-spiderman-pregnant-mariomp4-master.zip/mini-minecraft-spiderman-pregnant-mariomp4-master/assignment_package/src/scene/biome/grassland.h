#ifndef GRASSLAND_H
#define GRASSLAND_H

#include "biome.h"

class Grassland : public Biome
{
public:
    Grassland() {}
    static float getHeightValue(int x, int z);
    static float createBlockStack(int x, int z, int height, Chunk* c);
};

#endif // GRASSLAND_H
