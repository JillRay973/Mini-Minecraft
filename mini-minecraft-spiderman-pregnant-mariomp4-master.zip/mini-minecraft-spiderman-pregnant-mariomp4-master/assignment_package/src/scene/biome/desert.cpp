#include "desert.h"

float Desert::getHeightValue(int x, int z) {
    float f = 128 + (400 * Noise::domainWarpFbm(x, z, 1.0, 1.0 / 1500, 0.5));
    return f;
}

float Desert::createBlockStack(int x_in, int z_in, int height, Chunk* c) {
    int x = x_in - c->minX;
    int z = z_in - c->minZ;

        for (int y = 0; y < stoneHeight; y++) {
            c->setBlockAt(x, y, z, STONE);
        }

    for (int y = stoneHeight; y < height; y++) {
        c->setBlockAt(x, y, z, SAND);
    }

    c->setBlockAt(x, height, z, SAND);

    if (height < 138) {
        for (int y = 128; y < 138; y++) {
            if (c->getBlockAt(x, y, z) == EMPTY) {
                c->setBlockAt(x, y, z, WATER);
            }
        }
    }

}
