#include "beach.h"

float Beach::getHeightValue(int x, int z) {
    float f = 120 + (40 * Noise::domainWarpFbm(x, z, 1.0, 1.0 / 100, 0.5));
    return f;
}

float Beach::createBlockStack(int x_in, int z_in, int height, Chunk* c) {
    int x = x_in - c->minX;
    int z = z_in - c->minZ;

    for (int y = 0; y < stoneHeight; y++) {
        c->setBlockAt(x, y, z, STONE);
    }

    for (int y = stoneHeight; y < height; y++) {
        c->setBlockAt(x, y, z, SAND);
    }

    c->setBlockAt(x, height, z, SAND);

}
