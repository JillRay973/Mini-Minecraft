#ifndef BIOME_H
#define BIOME_H
#include "scene/chunk.h"
#include "scene/noise.h"
#include "scene/terrain.h"


class Biome
{
public:
    static constexpr float rarity = 1.f; // varies from most common, 1, to not appearing, 0
    static constexpr int stoneHeight = 100;
//    virtual float getHeightValue(int x, int z) = 0;
//    virtual float createBlockStack(int x, int z, int height, Chunk& c) = 0;
};

#endif // BIOME_H
