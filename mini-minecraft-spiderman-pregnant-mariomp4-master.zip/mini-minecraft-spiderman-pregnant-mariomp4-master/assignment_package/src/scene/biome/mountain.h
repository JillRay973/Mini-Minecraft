#ifndef MOUNTAIN_H
#define MOUNTAIN_H

#include "biome.h"

class Mountain : public Biome
{
public:
    Mountain() {}
    static float getHeightValue(int x, int z);
    static float createBlockStack(int x, int z, int height, Chunk* c);
};

#endif // MOUNTAIN_H
