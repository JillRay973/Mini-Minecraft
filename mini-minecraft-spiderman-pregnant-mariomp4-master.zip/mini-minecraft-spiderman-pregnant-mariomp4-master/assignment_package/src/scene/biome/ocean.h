#ifndef OCEAN_H
#define OCEAN_H

#include "biome.h"

class Ocean : public Biome
{
public:
    Ocean() {}
    static float getHeightValue(int x, int z);
    static float createBlockStack(int x, int z, int height, Chunk* c);
};

#endif // OCEAN_H
