#include "ocean.h"

float Ocean::getHeightValue(int x, int z) {
    float f = 40 * (1 * Noise::domainWarpFbm(x, z, 1.0, 1.0 / 40, 0.5));
    return f;
}

float Ocean::createBlockStack(int x, int z, int height, Chunk* c) {
    x -= c->minX;
    z -= c->minZ;
    for (int y = 0; y < height; y++) {
        //c->setBlockAt(x, y, z, STONE);
    }

    for (int y = 0; y <= 140; y++) {
        c->setBlockAt(x, y, z, WATER);
    }

}
