#ifndef SNOW_H
#define SNOW_H

#include "biome.h"

class Snow : public Biome
{
public:
    Snow() {}
    static float getHeightValue(int x, int z);
    static float createBlockStack(int x, int z, int height, Chunk* c);
};

#endif // SNOW_H
