#ifndef SWAMP_H
#define SWAMP_H

#include "biome.h"

class Swamp : public Biome
{
public:
    Swamp() {}
    static float getHeightValue(int x, int z);
    static float createBlockStack(int x, int z, int height, Chunk* c);
};

#endif // SWAMP_H
