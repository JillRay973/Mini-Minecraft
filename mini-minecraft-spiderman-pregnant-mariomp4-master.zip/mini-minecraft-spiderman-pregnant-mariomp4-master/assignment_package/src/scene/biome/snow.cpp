#include "snow.h"

float Snow::getHeightValue(int x, int z) {
    float f = 128 + (128 * Noise::domainWarpFbm(x, z, 1.0, 1.0 / 1028, 0.5));
    return f;
}

float Snow::createBlockStack(int x, int z, int height, Chunk* c) {
    x -= c->minX;
    z -= c->minZ;
    for (int y = 0; y <= height; y++) {
        c->setBlockAt(x, y, z, SNOW);
    }

    if (height < 138) {
        for (int y = 128; y < 138; y++) {
            if (c->getBlockAt(x, y, z) == EMPTY) {
                c->setBlockAt(x, y, z, ICE);
            }
        }
    }


}
