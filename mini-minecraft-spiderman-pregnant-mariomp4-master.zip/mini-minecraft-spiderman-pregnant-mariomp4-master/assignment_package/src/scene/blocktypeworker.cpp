#include "blocktypeworker.h"
#include "noise.h"
#include "biome/grassland.h"
#include "biome/mountain.h"
#include "biome/desert.h"
#include "biome/snow.h"
#include "biome/swamp.h"
#include "biome/ocean.h"
#include "biome/beach.h"
#include <iostream>

BlockTypeWorker::BlockTypeWorker(Chunk* c, std::unordered_set<Chunk*>& toVbo, QMutex& vboLock) : c(c), vboLock(vboLock), toVbo(toVbo), id(ids++) {
//    std::cout << "Making block worker " << c->id << " from thread " << this << std::endl;
}

void setBlockAtHelper(int x, int y, int z, BlockType block, Chunk *c) {
    int cornerX = static_cast<int>(glm::floor((x + c->minX) / 16.f)) *16;
    int cornerZ = static_cast<int>(glm::floor((z + c->minZ) / 16.f)) *16;

    if (cornerX != c->minX || cornerZ != c->minZ){ //if chunk is crossed
        if (cornerX != c->minX && cornerZ == c->minZ){
            if (x < 0) {
                Chunk *neighbor = c->m_neighbors[XNEG];
                if (neighbor) {
                    neighbor->setBlockAt(x + 16, y, z, block);
                }
            } else {
                Chunk *neighbor = c->m_neighbors[XNEG];
                if (neighbor) {
                    neighbor->setBlockAt(x - 16, y, z, block);
                }
            }
        } else if (cornerX == c->minX && cornerZ != c->minZ){
            if (z < 0) {
                Chunk *neighbor = c->m_neighbors[ZNEG];
                if (neighbor) {
                    neighbor->setBlockAt(x, y, z + 16, block);
                }
            } else {
                Chunk *neighbor = c->m_neighbors[ZPOS];
                if (neighbor) {
                    neighbor->setBlockAt(x, y, z - 16, block);
                }
            }
        } else {
            Chunk *neighbor;
            if (x < 0) {
                neighbor = c->m_neighbors[XNEG];
            } else {
                neighbor = c->m_neighbors[XPOS];
            }

            if (z < 0) {
                neighbor = neighbor->m_neighbors[ZNEG];
                if (x < 0 && neighbor) {
                    neighbor->setBlockAt(x + 16, y, z + 16, block);

                } else {
                    if (neighbor) {
                        neighbor->setBlockAt(x - 16, y, z + 16, block);
                    }
                }
            } else {
                neighbor = neighbor->m_neighbors[ZPOS];
                if (x < 0 && neighbor) {
                    neighbor->setBlockAt(x + 16, y, z - 16, block);
                } else {
                    if (neighbor) {
                        neighbor->setBlockAt(x - 16, y, z - 16, block);
                    }
                }
            }
        }
    } else {
        c->setBlockAt(x, y, z, block);
    }
}



void BlockTypeWorker::generateTree(int i, int j, int k) {
    for (int y = j; y <= j+4; y++) c->setBlockAt(i, y, k, LOG);

    for (int x = i-2; x <= i+2; x++) {
        for (int z = k-2; z <= k+2; z++) {
            setBlockAtHelper(x, j+2, z, LEAVES, c);
            setBlockAtHelper(x, j+3, z, LEAVES, c);
        }
    }

    for (int x = i-1; x <= i+1; x++) {
        for (int z = k-1; z <= k+1; z++) {
            setBlockAtHelper(x, j+4, z, LEAVES, c);
        }
    }

    c->setBlockAt(i-1, j+5, k, LEAVES);
    c->setBlockAt(i+1, j+5, k, LEAVES);
    c->setBlockAt(i, j+5, k+1, LEAVES);
    c->setBlockAt(i, j+5, k-1, LEAVES);
}

void BlockTypeWorker::generateBirchTree(int i, int j, int k) {
    for (int y = j; y <= j+4; y++) c->setBlockAt(i, y, k, BIRCH_LOG);

    for (int x = i-2; x <= i+2; x++) {
        for (int z = k-2; z <= k+2; z++) {
            setBlockAtHelper(x, j+2, z, LEAVES, c);
            setBlockAtHelper(x, j+3, z, LEAVES, c);
        }
    }

    for (int x = i-1; x <= i+1; x++) {
        for (int z = k-1; z <= k+1; z++) {
            setBlockAtHelper(x, j+4, z, LEAVES, c);
        }
    }

    c->setBlockAt(i-1, j+5, k, LEAVES);
    c->setBlockAt(i+1, j+5, k, LEAVES);
    c->setBlockAt(i, j+5, k+1, LEAVES);
    c->setBlockAt(i, j+5, k-1, LEAVES);
}

void BlockTypeWorker::generateCactus(int i, int j, int k) {
    float rand = Noise::noise1d(i, k);

    if (rand < 0.5) {
        for (int y = j; y <= j+2; y++) c->setBlockAt(i, y, k, CACTUS);
    } else {
        for (int y = j; y <= j+3; y++) c->setBlockAt(i, y, k, CACTUS);
    }

}

void BlockTypeWorker::generateIcicle(int i, int j, int k) {
    float rand = Noise::noise1d(i, k);

    if (rand < 0.5) {
        for (int y = j; y <= j+6; y++) {
            c->setBlockAt(i, y, k, ICE);
            if (y <= j+4) {
                c->setBlockAt(i+1, y, k, ICE);
                c->setBlockAt(i-1, y, k, ICE);
            }
            if (y <= j+2) {
                c->setBlockAt(i, y, k+1, ICE);
                c->setBlockAt(i, y, k-1, ICE);
            }
        }

    } else {
        for (int y = j; y <= j+3; y++) {
            c->setBlockAt(i, y, k, ICE);
            if (y <= j+1) {
                c->setBlockAt(i, y, k+1, ICE);
                c->setBlockAt(i, y, k-1, ICE);
                c->setBlockAt(i+1, y, k, ICE);
                c->setBlockAt(i-1, y, k, ICE);
            }
        }
    }
}

void BlockTypeWorker::run() {
    try {

    //generate biomes
    for (int i = c->minX; i < c->minX + 16; i++) {
        for (int j = c->minZ; j < c->minZ + 16; j++) {
            int temperature = 0;
            Continent continent;
            int erosion = 0;

            float height;

            //get temperature value
            float tempValue = Noise::noisev2(glm::vec2(.05 + i * 0.005, .05 + j * 0.005)) * 3.5;
            if (tempValue < -0.40) {
                temperature = 0; //cool
            } else if (tempValue >= -0.40 && tempValue < 0.40) {
                temperature = 1; //mid
            } else {
                temperature = 2; //warm
            }

            //get continental biome type
            glm::vec2 pCont = glm::vec2(.01 + i * 0.005, .01 + j * 0.005);
            float contValue = Noise::perlin2dv2(pCont) * 2.5;
            if (contValue < -0.500) {
                continent = OCEAN;
            } else if (contValue >= -0.500 && contValue < -0.400) {
                continent = COAST;
            } else if (contValue >= -0.400 && contValue < -.1) {
                continent = NEAR_INLAND;
            } else if (contValue >= -.1 && contValue < 0.6) {
                continent = MID_INLAND;
            } else {
                continent = FAR_INLAND;
            }

            //get erosion
            glm::vec2 pErosion = glm::vec2(1.5 + i * 0.004, .5 + j * 0.004);
            float erosionValue = Noise::perlin2dv2(pErosion) * 2.5;

            //biome = Noise::noisev2(glm::vec2(.01 + i * 0.01, .01 + j * 0.01));
            float tempSmooth =  glm::smoothstep(0.0f, 1.0f, tempValue);
            float contSmooth = glm::smoothstep(0.0f, 1.0f, contValue);
            float erosionSmooth = glm::smoothstep(0.0f, 1.0f, erosionValue);

            float mountain = Mountain::getHeightValue(i, j);
            float grassland = Grassland::getHeightValue(i, j);
            float snow = Snow::getHeightValue(i, j);
            float desert = Desert::getHeightValue(i, j);
            float ocean = Ocean::getHeightValue(i, j);
            float beach = Beach::getHeightValue(i, j);

            float mixFlat = glm::mix(desert, snow, erosionSmooth);
            float mixRocky = glm::mix(grassland, mountain, erosionSmooth);
            //float mixCoast = glm::mix(ocean, beach, erosionSmooth);
            height = glm::mix(mixFlat, mixRocky, tempSmooth);
            //height = glm::mix(mixCoast, height, contSmooth);

            if (temperature == 2) {
                if (erosionSmooth > 0.5) {
                        Desert::createBlockStack(i, j, height, c); //"flat"
                } else {
                        Grassland::createBlockStack(i, j, height, c); //"rocky"
                }
            } else if (temperature == 1) {
                if (erosionSmooth > 0.5) {
                        Swamp::createBlockStack(i, j, height, c); //"flat"
                } else {
                        Mountain::createBlockStack(i, j, height, c); //"rocky"
                }
            } else {
                if (erosionSmooth > 0.5) {
                        Snow::createBlockStack(i, j, height, c); //"flat"
                } else {
                        Mountain::createBlockStack(i, j, height, c); //"rocky"
                }
            }

        }
    }

    //creates caves
    for (int i = c->minX; i < c->minX + 16; i++) {
        for (int j = 1; j <= 120; j++) {
            for (int k = c->minZ; k < c->minZ + 16; k++) {
                float cave = Noise::perlinNoise3D(glm::vec3(i / 40.f, j / 40.f, k / 40.f), true);
                float cave2 = Noise::perlinNoise3D(glm::vec3(i / 40.f, j / 40.f, k / 40.f), false);

                float caveTotal = cave * cave + cave2 * cave2;

                glm::vec2 pCont = glm::vec2(.01 + i * 0.005, .01 + j * 0.005);
                float contValue = Noise::perlin2dv2(pCont) * 2.5;

                if (abs(caveTotal) < 0.005 && contValue >= -0.500) {
                    if (j < 25 && c->getBlockAt(i - c->minX, j, k - c->minZ != WATER)) {
                        c->setBlockAt(i - c->minX, j, k - c->minZ, LAVA);
                    } else {
                        c->setBlockAt(i - c->minX, j, k - c->minZ, EMPTY);
                    }
                } else {

                }
            }
        }
    }

    //set bedrock
    for (int i = c->minX; i < c->minX + 16; i++) {
        for (int j = c->minZ; j < c->minZ + 16; j++) {
            c->setBlockAt(i - c->minX, 0, j - c->minZ, BEDROCK);
        }
    }

    //create structures
    for (int i = c->minX; i < c->minX + 16; i++) {
        for (int j = c->minZ; j < c->minZ + 16; j++) {
            float hasStruct;
            hasStruct =  Noise::noisev2(glm::vec2(.01 + i * 0.05, .01 + j * 0.05));

            if (hasStruct < 0.002) {
                for (int k = 200; k >= 0; k--) {
                    int x = i - c->minX;
                    int z = j - c->minZ;
                    BlockType b = c->getBlockAt(x, k+1, z);
                    if (b != EMPTY) {
                        if (b == WATER) {
                            break;
                        } else if (b == DIRT || b == GRASS || b == WEIRD_DIRT) {
                            if (x >= 2 && x <= 13 && z >= 2 && z <= 13) {
                                float rand = Noise::noise1d(i, k);
                                if (rand < 0.5) {
                                    generateBirchTree(x, k+1, z);
                                } else {
                                    generateTree(x, k+1, z);
                                }
                            }
                            i += 4;
                            j += 5;
                            break;
                        } else if (b == SAND) {
                            generateCactus(x, k+1, z);
                            i += 9;
                            j += 10;
                        } else if (b == SNOW) {
                            if (x >= 1 && x <= 14 && z >= 1 && z <= 14) {
                                generateIcicle(x, k+1, z);
                            }
                            i += 8;
                            j += 7;
                        }
                    }
                }
            }
        }
    }


    for (int i = c->minX; i < c->minX + 16; i++) {
        for (int j = c->minZ; j < c->minZ + 16; j++) {
            //c->setBlockAt(i - c->minX, 140, j - c->minZ, WATER);
        }
    }

    vboLock.lock();
    toVbo.insert(c);
    vboLock.unlock();

    } catch (const std::exception &exc) {
    // catch anything thrown within try block that derives from std::exception
    std::cerr << "Error in chunk " << c->id << " for worker " << id << ": " << exc.what() << std::endl;
    }

}
