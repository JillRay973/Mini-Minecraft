#include "player.h"
#include <QString>
#include "iostream"
#include "mygl.h"

Player::Player(glm::vec3 pos, const Terrain &terrain)
    : Entity(pos), m_velocity(0,0,0), m_acceleration(0,0,0),
    m_camera(pos + glm::vec3(0, 1.5, 0)), mcr_terrain(terrain), ifAxis(-1),
    mcr_camera(m_camera),  c(c), data(std::make_unique<VBOData>())
{


}

Player::~Player()
{
     c->generateVBOData(data.get());
}

void Player::tick(float dT, InputBundle &input) {
    computePhysics(dT, mcr_terrain, input);
    processInputs(mcr_terrain, input);
}

void Player::processInputs(const Terrain &terrain, InputBundle &inputs) {
    float acceleration = 30.0f;

    if (inputs.inflightMode) {

        if (inputs.wPressed) {
            m_acceleration = 2 * acceleration * this->m_forward;
        }
        else if (inputs.sPressed) {
            m_acceleration = 2 * -acceleration * this->m_forward;
        }
        else if (inputs.dPressed) {
            m_acceleration = 2 * acceleration * this->m_right;
        }
        else if (inputs.aPressed) {
            m_acceleration = 2 * -acceleration * this->m_right;
        }
        else if (inputs.ePressed) {
            m_acceleration = 2 * acceleration * glm::vec3(0.f, 1.f, 0.f);
        }
        else if (inputs.qPressed) {
            m_acceleration = 2 * acceleration * glm::vec3(0.f, -1.f, 0.f);
        }
        else {
            m_velocity = vec3();
            m_acceleration = vec3();
        }
    } else { //not flying

        isplayeronGround(terrain, inputs);
        if (inputs.wPressed) {
            m_acceleration = acceleration * normalize(vec3(m_forward.x, 0, m_forward.z));
        }
        else if (inputs.sPressed) {
            m_acceleration = -acceleration * normalize(vec3(m_forward.x, 0, m_forward.z));
        }
        else if (inputs.dPressed) {
            m_acceleration = acceleration * normalize(vec3(m_right.x, 0, m_right.z));
        }
        else if (inputs.aPressed) {
            m_acceleration = -acceleration * normalize(vec3(m_right.x, 0, m_right.z));
        }
        else if (inputs.spacePressed) {
            if (inputs.inWater || inputs.inLava) {
                m_velocity.y += 50.0f;
            } else if (inputs.onGround) {
                // jump on ground
                m_velocity = acceleration * this->m_up;
            }
        } else {
            m_velocity = vec3();
            m_acceleration = vec3();
        }

    }
}

void Player::computePhysics(float dT, const Terrain &terrain, InputBundle &input) {
    // TODO: Update the Player's position based on its acceleration
    // and velocity, and also perform collision detection.
    // four main kinematics equations :
    //1) velocity = initial velocity + acceleration(time)
    //2) Change in position = ((velocity + initial velocity)/2) * time
    //3) change in position = (initial velocity * time) + (1/2)(acceleration)(time^2)
    //4) velocity^2 = (initial velocty)^2 + 2(acceleration)(change in position)
    //Of course, acceleration is also just the derivative of velocity, which is the derivative of position
    //In both movement modes, the player's velocity is reduced to less than 100% of its current value every frame (simulates friction + drag)

    m_velocity *= 0.95f; // reduce velocity for friction + drag
    m_velocity += m_acceleration * dT;
    vec3 raycast = m_velocity * dT;
    vec3 gravity = vec3(0.f, -98.f, 0.f); // -9.8 for gravity * 10 for mass lol

    // handle collision & gravity while the player is in non-flightmode
    // if the player is not on ground, apply gravity
    if (!input.inflightMode) {
        isPlayerInWater(terrain, input);
        isPlayerInLava(terrain, input);
        isplayeronGround(terrain, input);
        if (!input.onGround || input.inWater || input.inLava) {
            // falling
            m_acceleration = gravity;
            m_velocity += m_acceleration * dT;
        } else if (input.onGround && !input.spacePressed) {
            // come back down after jumping on ground
            m_velocity.y = 0.f;
        }
        raycast = m_velocity * dT;
        collision(&raycast, terrain);
    }
    this->moveAlongVector(raycast);
}

void Player::setCameraWidthHeight(unsigned int w, unsigned int h) {
    m_camera.setWidthHeight(w, h);
}

void Player::moveAlongVector(glm::vec3 dir) {
    Entity::moveAlongVector(dir);
    m_camera.moveAlongVector(dir);
}
void Player::moveForwardLocal(float amount) {
    Entity::moveForwardLocal(amount);
    m_camera.moveForwardLocal(amount);
}
void Player::moveRightLocal(float amount) {
    Entity::moveRightLocal(amount);
    m_camera.moveRightLocal(amount);
}
void Player::moveUpLocal(float amount) {
    Entity::moveUpLocal(amount);
    m_camera.moveUpLocal(amount);
}
void Player::moveForwardGlobal(float amount) {
    Entity::moveForwardGlobal(amount);
    m_camera.moveForwardGlobal(amount);
}
void Player::moveRightGlobal(float amount) {
    Entity::moveRightGlobal(amount);
    m_camera.moveRightGlobal(amount);
}
void Player::moveUpGlobal(float amount) {
    Entity::moveUpGlobal(amount);
    m_camera.moveUpGlobal(amount);
}
void Player::rotateOnForwardLocal(float degrees) {
    Entity::rotateOnForwardLocal(degrees);
    m_camera.rotateOnForwardLocal(degrees);
}
void Player::rotateOnRightLocal(float degrees) {
    Entity::rotateOnRightLocal(degrees);
    m_camera.rotateOnRightLocal(degrees);
}
void Player::rotateOnUpLocal(float degrees) {
    Entity::rotateOnUpLocal(degrees);
    m_camera.rotateOnUpLocal(degrees);
}
void Player::rotateOnForwardGlobal(float degrees) {
    Entity::rotateOnForwardGlobal(degrees);
    m_camera.rotateOnForwardGlobal(degrees);
}
void Player::rotateOnRightGlobal(float degrees) {
    Entity::rotateOnRightGlobal(degrees);
    m_camera.rotateOnRightGlobal(degrees);
}
void Player::rotateOnUpGlobal(float degrees) {
    Entity::rotateOnUpGlobal(degrees);
    m_camera.rotateOnUpGlobal(degrees);
}

QString Player::posAsQString() const {
    std::string str("( " + std::to_string(m_position.x) + ", " + std::to_string(m_position.y) + ", " + std::to_string(m_position.z) + ")");
    return QString::fromStdString(str);
}
QString Player::velAsQString() const {
    std::string str("( " + std::to_string(m_velocity.x) + ", " + std::to_string(m_velocity.y) + ", " + std::to_string(m_velocity.z) + ")");
    return QString::fromStdString(str);
}
QString Player::accAsQString() const {
    std::string str("( " + std::to_string(m_acceleration.x) + ", " + std::to_string(m_acceleration.y) + ", " + std::to_string(m_acceleration.z) + ")");
    return QString::fromStdString(str);
}
QString Player::lookAsQString() const {
    std::string str("( " + std::to_string(m_forward.x) + ", " + std::to_string(m_forward.y) + ", " + std::to_string(m_forward.z) + ")");
    return QString::fromStdString(str);
}
bool Player::isplayeronGround(const Terrain &terrain, InputBundle &input) {
    vec3 screencorner = this->m_position - vec3(0.5f, 0, 0.5f);
    for (int x = 0; x <= 1; x++) {
        for (int z = 0; z <= 1; z++) {
            vec3 pos = vec3(floor(screencorner.x) + x, floor(screencorner.y - 0.005f),
                            floor(screencorner.z) + z);
            if (terrain.getBlockAt(pos) != EMPTY && terrain.getBlockAt(pos) != WATER) {
                input.onGround = true;
            }
            else {
                input.onGround = false;
            }
        }
    }
    return input.onGround;
}

bool Player::isPlayerInWater(const Terrain &terrain, InputBundle &input) {
    std::vector<glm::vec3> origins;

    for (int i = 0; i < 3; i++) {
        origins.push_back(m_position + glm::vec3(-0.4, i + 0.005, -0.4));
        origins.push_back(m_position + glm::vec3(-0.4, i + 0.005, 0.4));
        origins.push_back(m_position + glm::vec3(0.4, i + 0.005, -0.4));
        origins.push_back(m_position + glm::vec3(0.4, i + 0.005, 0.4));
    }

    for (glm::vec3 &pos : origins) {
        BlockType type = terrain.getBlockAt(glm::floor(pos[0]), glm::floor(pos[1]), glm::floor(pos[2]));
        if (type == WATER) {
            input.inWater = true;
            return true;
        }
    }
    input.inWater = false;
    return false;
}

bool Player::isPlayerInLava(const Terrain &terrain, InputBundle &input) {
    std::vector<glm::vec3> origins;

    for (int i = 0; i < 3; i++) {
        origins.push_back(m_position + glm::vec3(-0.3, i + 0.015, -0.3));
        origins.push_back(m_position + glm::vec3(-0.3, i + 0.015, 0.3));
        origins.push_back(m_position + glm::vec3(0.3, i + 0.015, -0.3));
        origins.push_back(m_position + glm::vec3(0.3, i + 0.015, 0.3));
    }

    for (glm::vec3 &pos : origins) {
        BlockType type = terrain.getBlockAt(glm::floor(pos[0]), glm::floor(pos[1]), glm::floor(pos[2]));
        if (type == LAVA) {
            input.inLava = true;
            return true;
        }
    }
    input.inLava = false;
    return false;
}



void Player::collision(vec3 *raycast, const Terrain &terrain) {
    glm::vec3 boundingBoxMin = this->m_position - glm::vec3(0.5f, 0.0f, 0.5f);

    //coordinates of block that was hit
    glm::ivec3 out_blockHit = glm::ivec3();
    //distance to block that was hit
    float out_dist = 0.0f;

    bool collision = false;

    //loop over bounding box dimensions to check if player's next movement results in a collision
    //dimensions: 1 in x, 2 in y, 1 in z
    //treat player as a 1x2x1 block
    for(int x = 0; x <= 1; x++){
        for(int z = 1; z >= 0 ; z--){
            for(int y = 0; y <= 2; y++){
                glm::vec3 rayOrigin = boundingBoxMin + glm::vec3(x, y, z);
                //GRID MARCH: shoot out ray and check for intersection
                if(gridMarch(rayOrigin, *raycast, terrain, &out_dist, &out_blockHit)){
                    //calculate minimum distance of distance:
                    //distance to the hit block (outDist)
                    //distance from player position to the hit block

                    // If any of these rays intersect with a non-empty block in the terrain, it updates the *rayDir with the minimum distance to the block
                    float distance = glm::min(out_dist - 0.005f, glm::length(this->m_position - glm::vec3(out_blockHit)));
                    //update ray's direction:
                    *raycast = distance * glm::normalize(*raycast);
                    collision = true;
                }
            }
        }
    }
}


bool Player::gridMarch(glm::vec3 raycastcenter, glm::vec3 raycast,
                       const Terrain &terrain, float *hitdistance,
                       glm::ivec3 *hitblock) {
    float farthestdist = glm::length(raycast); // farthest we search
    glm::ivec3 currentblock = glm::ivec3(glm::floor(raycastcenter));
    raycast = glm::normalize(raycast); // now all t values represent world dist

    float currentime = 0.f;
    while (currentime < farthestdist) {
        float mintime = glm::sqrt(3.f);
        float axis = -1; // Track axis for which t is smallest
        for (int i = 0; i < 3; ++i) { // Iterate over the three axes
            if (raycast[i] != 0) { // Is ray parallel to axis i?
                float offset = glm::max(0.f, glm::sign(raycast[i]));

                // If the player is *exactly* on an interface then
                // they'll never move if they're looking in a negative direction
                if (currentblock[i] == raycastcenter[i] && offset == 0.f) {
                    offset = -1.f;
                }
                int nextcollision = currentblock[i] + offset;
                float axis_t = (nextcollision - raycastcenter[i]) / raycast[i];
                axis_t = glm::min(axis_t, farthestdist); // Clamp to max len to avoid super out of bounds errors
                if (axis_t < mintime) {
                    mintime = axis_t;
                    axis = i;
                }
            }
        }
        if (axis == -1) {
            throw std::out_of_range("axis was -1 after the for loop in gridMarch!");
        }
        ifAxis = axis;
        currentime += mintime;
        raycastcenter += raycast * mintime;
        glm::ivec3 offset = glm::ivec3(0, 0, 0);
        // Sets it to 0 if sign is +, -1 if sign is -
        offset[axis] = glm::min(0.f, glm::sign(raycast[axis]));
        currentblock = glm::ivec3(glm::floor(raycastcenter)) + offset;
        // If the currentblock contains something other than empty, return currentime
        BlockType blocktype = terrain.getBlockAt(currentblock.x, currentblock.y, currentblock.z);

        // there's a block thts not water/lava, return yes for collision
        if (blocktype != EMPTY) {
            *hitblock = currentblock;
            *hitdistance = glm::min(farthestdist, currentime);
            return true;
        }
    }

    *hitdistance = glm::min(farthestdist, currentime);
    return false;
}



BlockType Player::removeblock(Terrain *terrain) {

    vec3 rayOrigin = m_camera.mcr_position;
    vec3 rayDirection = 3.f * glm::normalize(this->m_forward);
    float outDist = 0.f;
    ivec3 outBlockHit = ivec3();

    if (gridMarch(rayOrigin, rayDirection, *terrain, &outDist, &outBlockHit)) {
        BlockType blockType = terrain->getBlockAt(outBlockHit.x, outBlockHit.y, outBlockHit.z);
        if (blockType != BEDROCK) {
            terrain->setBlockAt(outBlockHit.x, outBlockHit.y, outBlockHit.z, EMPTY);
        }

        auto &chunk = terrain->getChunkAt(outBlockHit.x, outBlockHit.z);
        chunk->destroyVBOdata();
        chunk->generateVBOData(chunk->getVBOpointer().get());
        chunk->createVBOdata();
        std::cout << "remove block" << std::endl;
        return blockType;
    }
    return EMPTY;

}

BlockType Player::addBlock(Terrain *terrain, BlockType currBlockType) {
    vec3 rayOrigin = m_camera.mcr_position;
    vec3 rayDirection = 3.f * glm::normalize(this->m_forward);
    float outDist = 0.f;
    ivec3 outBlockHit = ivec3();

    if (gridMarch(rayOrigin, rayDirection, *terrain, &outDist, &outBlockHit)) {
        if (terrain->getBlockAt(outBlockHit.x, outBlockHit.y, outBlockHit.z + glm::sign(rayDirection.z)) == EMPTY) {
            terrain->setBlockAt(outBlockHit.x , outBlockHit.y , outBlockHit.z  + ( glm::sign(rayDirection.z)), currBlockType);
                auto &chunk = terrain->getChunkAt(outBlockHit.x, outBlockHit.z);
                chunk->destroyVBOdata();
                chunk->generateVBOData(chunk->getVBOpointer().get());
                chunk->createVBOdata();

                std::cout << "create" << std::endl;
                return currBlockType;
            }
        if (terrain->getBlockAt(outBlockHit.x, outBlockHit.y  + glm::sign(rayDirection.y), outBlockHit.z) == EMPTY) {
                terrain->setBlockAt(outBlockHit.x , outBlockHit.y + ( glm::sign(rayDirection.y)) , outBlockHit.z , currBlockType);
                auto &chunk = terrain->getChunkAt(outBlockHit.y, outBlockHit.z);
                chunk->destroyVBOdata();
                chunk->generateVBOData(chunk->getVBOpointer().get());
                chunk->createVBOdata();

                std::cout << "create" << std::endl;
                return currBlockType;
        }
        if (terrain->getBlockAt(outBlockHit.x + glm::sign(rayDirection.x), outBlockHit.y, outBlockHit.z) == EMPTY) {
                terrain->setBlockAt(outBlockHit.x + glm::sign(rayDirection.x), outBlockHit.y , outBlockHit.z , currBlockType);
                auto &chunk = terrain->getChunkAt(outBlockHit.x, outBlockHit.y);
                chunk->destroyVBOdata();
                chunk->generateVBOData(chunk->getVBOpointer().get());
                chunk->createVBOdata();

                std::cout << "create" << std::endl;
                return currBlockType;
        }
        }

    return EMPTY;
}


