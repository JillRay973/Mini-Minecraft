
#include "chunk.h"
#include <iostream>
#include <ostream>
#include <QThreadPool>
#include <QMutexLocker>

Chunk::Chunk(OpenGLContext* context, Terrain* t, int x, int z) : Drawable(context), id(chunkIds++), m_blocks(), t(t), minX(x), minZ(z), m_neighbors{{XPOS, nullptr}, {XNEG, nullptr}, {ZPOS, nullptr}, {ZNEG, nullptr}}
{
    std::fill_n(m_blocks.begin(), 65536, EMPTY);
}

glm::vec3 Chunk::getBlockColor(BlockType b) {
    switch(b) {
    case GRASS:
        return glm::vec3(95.f, 159.f, 53.f) / 255.f;
        break;
    case DIRT:
        return glm::vec3(121.f, 85.f, 58.f) / 255.f;
        break;
    case STONE:
        return glm::vec3(0.5f);
        break;
    case WATER:
        return glm::vec3(0.f, 0.f, 0.75f);
        break;
    case BEDROCK:
        return glm::vec3(0.f, 0.f, 0.f);
        break;
    case LAVA:
        return glm::vec3(0.75f, 0.f, 0.f);
        break;
    default:
        // Other block types are not yet handled, so we default to debug purple
        return glm::vec3(1.f, 0.f, 1.f);
        break;
    }
}


void Chunk::interweave(std::vector<glm::vec4>* posColNor, glm::vec4 pos, glm::vec4 col, glm::vec4 nor) {
    posColNor->push_back(pos);
    posColNor->push_back(col);
    posColNor->push_back(nor);
}

bool isTrans(BlockType t) {
    return t == WATER || t == LAVA;
}

void Chunk::bufferIndices(int &index, std::vector<GLuint> &idx) {
    int curIdx = index + 1;

    idx.push_back(index);
    idx.push_back(curIdx);
    idx.push_back(curIdx + 1);
    curIdx++;
    idx.push_back(index);
    idx.push_back(curIdx);
    idx.push_back(curIdx + 1);
    index += 4;
}

void Chunk::createVBOdata() {

    std::vector<glm::vec4>& interleave_opq = vTemp->opqAttrs;
    std::vector<glm::vec4>& interleave_trans = vTemp->trnsAttrs;
    std::vector<GLuint>& idx_opq = vTemp->opqIdx;
    std::vector<GLuint>& idx_trans = vTemp->trnsIdx;

    m_countOpq = idx_opq.size();
    m_countTrans = idx_trans.size();

    generateOpq();
    bindOpq();
    mp_context->glBufferData(GL_ARRAY_BUFFER, interleave_opq.size() * sizeof(glm::vec4), interleave_opq.data(), GL_STATIC_DRAW);

    generateIdxOpq();
    bindIdxOpq();
    mp_context->glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx_opq.size() * sizeof(GLuint), idx_opq.data(), GL_STATIC_DRAW);

    generateTrans();
    bindTrans();
    mp_context->glBufferData(GL_ARRAY_BUFFER, interleave_trans.size() * sizeof(glm::vec4), interleave_trans.data(), GL_STATIC_DRAW);

    generateIdxTrans();
    bindIdxTrans();
    mp_context->glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx_trans.size() * sizeof(GLuint), idx_trans.data(), GL_STATIC_DRAW);

}

void Chunk::generateVBOData(VBOData* unq) {

//    unq->clear();

    // for opaque blocks
    std::vector<GLuint>& idx_opq = unq->opqIdx;
    std::vector<glm::vec4>& interleave_opq = unq->opqAttrs;

    // for transparent blocks
    std::vector<GLuint>& idx_trans = unq->trnsIdx;
    std::vector<glm::vec4>& interleave_trans = unq->trnsAttrs;


    int faces_trans = 0;
    int vertices_trans = 0;

    int faces_opq = 0;
    int vertices_opq = 0;

    // iterates over all 3 coords of chunks
    for (int x = 0; x < 16; ++x) {
        for (int y = 0; y < 256; ++y) {
            for (int z = 0; z < 16; ++z) {

                BlockType t = getBlockAt(x, y, z);
                glm::vec4 block(x, y, z, 0);

                glm::vec4 worldBlock(block + glm::vec4(minX, 0, minZ, 0));

                if (t != EMPTY) {

                    BlockType x_pos = getBlockAt(x + 1, y, z);
                    BlockType x_neg = getBlockAt(x - 1, y, z);
                    BlockType y_pos = getBlockAt(x, y + 1, z);
                    BlockType y_neg = getBlockAt(x, y - 1, z);
                    BlockType z_pos = getBlockAt(x, y, z + 1);
                    BlockType z_neg = getBlockAt(x, y, z - 1);

                    if (x == 0 && m_neighbors[XNEG]) {
                        x_neg = m_neighbors[XNEG]->getBlockAt(15, y, z);
                    }

                    if (x == 15 && m_neighbors[XPOS]) {
                        x_pos = m_neighbors[XPOS]->getBlockAt((x + 1) % 16, y, z);
                    }

                    if (y == 0) {
                        y_neg = EMPTY;
                    }

                    if (y == 255) {
                        y_pos = EMPTY;
                    }

                    if (z == 0 && m_neighbors[ZNEG]) {
                        z_neg = m_neighbors[ZNEG]->getBlockAt(x, y, 15);
                    }

                    if (z == 15 && m_neighbors[ZPOS]) {
                        z_pos = m_neighbors[ZPOS]->getBlockAt(x, y, 0);
                    }

                    if (x_pos == EMPTY || (isTrans(x_pos) && x_pos != t)) {
                        if (!isTrans(t)) {
                            updateVBO(interleave_opq,  XPOS, worldBlock, t, faces_opq++);
                        } else {
                            updateVBO(interleave_trans, XPOS, worldBlock, t, faces_trans++);
                        }
                    }

                    if (x_neg == EMPTY || (isTrans(x_neg) && x_neg != t)) {
                        if (!isTrans(t)) {
                            updateVBO(interleave_opq, XNEG, worldBlock, t, faces_opq++);
                        } else {
                            updateVBO(interleave_trans, XNEG, worldBlock, t, faces_trans++);
                        }
                    }

                    if (y_pos == EMPTY || (isTrans(y_pos) && y_pos != t)) {
                        if (!isTrans(t)) {
                            updateVBO(interleave_opq, YPOS, worldBlock, t, faces_opq++);
                        } else {
                            updateVBO(interleave_trans, YPOS, worldBlock, t, faces_trans++);
                        }
                    }

                    if (y_neg == EMPTY || (isTrans(y_neg) && y_neg != t)) {
                        if (!isTrans(t)) {
                            updateVBO(interleave_opq, YNEG, worldBlock, t, faces_opq++);
                        } else {
                            updateVBO(interleave_trans, YNEG, worldBlock, t, faces_trans++);
                        }
                    }

                    if (z_pos == EMPTY || (isTrans(z_pos) && z_pos != t)) {
                        if (!isTrans(t)) {
                            updateVBO(interleave_opq, ZPOS, worldBlock, t, faces_opq++);
                        } else {
                            updateVBO(interleave_trans, ZPOS, worldBlock, t, faces_trans++);
                        }
                    }

                    if (z_neg == EMPTY || (isTrans(z_neg) && z_neg != t)) {
                        if (!isTrans(t)) {
                            updateVBO(interleave_opq, ZNEG, worldBlock, t, faces_opq++);
                        } else {
                            updateVBO(interleave_trans, ZNEG, worldBlock, t, faces_trans++);
                        }
                    }
                }
            }
        }
    }

    for (int i = 0; i < faces_opq; i++) {
        idx_opq.push_back(vertices_opq);
        idx_opq.push_back(vertices_opq + 1);
        idx_opq.push_back(vertices_opq + 2);
        idx_opq.push_back(vertices_opq);
        idx_opq.push_back(vertices_opq + 2);
        idx_opq.push_back(vertices_opq + 3);
        vertices_opq += 4;
    }

    for (int i = 0; i < faces_trans; i++) {
        idx_trans.push_back(vertices_trans);
        idx_trans.push_back(vertices_trans + 1);
        idx_trans.push_back(vertices_trans + 2);
        idx_trans.push_back(vertices_trans);
        idx_trans.push_back(vertices_trans + 2);
        idx_trans.push_back(vertices_trans + 3);
        vertices_trans += 4;
    }

}

void Chunk::loadInterweaved(std::unordered_set<Chunk*>& retry) {
    QMutexLocker ml (&vboMutex);
    if (vTemp != nullptr) {
        m_countOpq = vTemp->opqIdx.size();
        m_countTrans = vTemp->trnsIdx.size();

        generateOpq();
        bindOpq();
        mp_context->glBufferData(GL_ARRAY_BUFFER, vTemp->opqAttrs.size() * sizeof(glm::vec4), vTemp->opqAttrs.data(), GL_STATIC_DRAW);

        generateTrans();
        bindTrans();
        mp_context->glBufferData(GL_ARRAY_BUFFER, vTemp->trnsAttrs.size() * sizeof(glm::vec4), vTemp->trnsAttrs.data(), GL_STATIC_DRAW);

        generateIdxOpq();
        bindIdxOpq();
        mp_context->glBufferData(GL_ELEMENT_ARRAY_BUFFER, vTemp->opqIdx.size() * sizeof(GLuint), vTemp->opqIdx.data(), GL_STATIC_DRAW);

        generateIdxTrans();
        bindIdxTrans();

        mp_context->glBufferData(GL_ELEMENT_ARRAY_BUFFER, vTemp->trnsIdx.size() * sizeof(GLuint), vTemp->trnsIdx.data(), GL_STATIC_DRAW);

        vboSet = true;
    } else {
        retry.insert(this);
    }
}

uPtr<VBOData>& Chunk::getVBOpointer() {
    return this->vTemp;
}

GLenum Chunk::drawMode() {
    return GL_TRIANGLES;
}

// Does bounds checking with at()
BlockType Chunk::getBlockAt(unsigned int x, unsigned int y, unsigned int z) {
    QMutexLocker ml (&mutex);
    return m_blocks.at(x + 16 * y + 16 * 256 * z);
}

// Exists to get rid of compiler warnings about int -> unsigned int implicit conversion
BlockType Chunk::getBlockAt(int x, int y, int z) {
    if (x > 15 || x < 0) {
        return EMPTY;
    }
    if (y > 255 || y < 0) {
        return EMPTY;
    }
    if (z > 15 || z < 0) {
        return EMPTY;
    }

    return getBlockAt(static_cast<unsigned int>(x), static_cast<unsigned int>(y), static_cast<unsigned int>(z));
}

int vertexAO(BlockType side1, BlockType side2, BlockType corner) {
    if (side1 != EMPTY && side2 != EMPTY) {
        return 3;
    } else {
        int result = 3;
        if (side1 == EMPTY) result--;
        if (side2 == EMPTY) result--;
        if (corner == EMPTY) result--;
        return result;
    }
}

int Chunk::findAO(Direction dir, glm::vec4 pos, int i) {
    BlockType side1 = EMPTY, side2 = EMPTY, corner = EMPTY;
    int x = pos.x;
    int y = pos.y;
    int z = pos.z;

    switch(dir) {
        case XPOS:
            switch(i) {
                case 0:
                    side1 = getBlockAt(x+1, y-1, z);
                    side2 = getBlockAt(x+1, y, z+1);
                    corner = getBlockAt(x+1, y-1, z+1);
                    break;
                case 1:
                    side1 = getBlockAt(x+1, y-1, z);
                    side2 = getBlockAt(x+1, y, z-1);
                    corner = getBlockAt(x+1, y-1, z-1);
                    break;
                case 2:
                    side1 = getBlockAt(x+1, y+1, z);
                    side2 = getBlockAt(x+1, y, z-1);
                    corner = getBlockAt(x+1, y+1, z-1);
                    break;
                case 3:
                    side1 = getBlockAt(x+1, y+1, z);
                    side2 = getBlockAt(x+1, y, z+1);
                    corner = getBlockAt(x+1, y+1, z+1);
                    break;
            }
            break;

        case XNEG:
            switch(i) {
                case 0:
                    side1 = getBlockAt(x+1, y-1, z);
                    side2 = getBlockAt(x+1, y, z-1);
                    corner = getBlockAt(x+1, y-1, z-1);
                    break;
                case 1:
                    side1 = getBlockAt(x+1, y-1, z);
                    side2 = getBlockAt(x+1, y, z+1);
                    corner = getBlockAt(x+1, y-1, z+1);
                    break;
                case 2:
                    side1 = getBlockAt(x-1, y+1, z);
                    side2 = getBlockAt(x-1, y, z+1);
                    corner = getBlockAt(x-1, y+1, z+1);
                    break;
                case 3:
                    side1 = getBlockAt(x+1, y+1, z);
                    side2 = getBlockAt(x+1, y, z-1);
                    corner = getBlockAt(x+1, y+1, z-1);
                    break;
            }
            break;

        case YPOS:
            switch(i) {
                case 0:
                    side1 = getBlockAt(x-1, y+1, z);
                    side2 = getBlockAt(x, y+1, z+1);
                    corner = getBlockAt(x-1, y+1, z+1);
                    break;
                case 1:
                    side1 = getBlockAt(x+1, y+1, z);
                    side2 = getBlockAt(x, y+1, z+1);
                    corner = getBlockAt(x+1, y+1, z+1);
                    break;
                case 2:
                    side1 = getBlockAt(x+1, y+1, z);
                    side2 = getBlockAt(x, y+1, z-1);
                    corner = getBlockAt(x+1, y+1, z-1);
                    break;
                case 3:
                    side1 = getBlockAt(x-1, y+1, z);
                    side2 = getBlockAt(x, y+1, z-1);
                    corner = getBlockAt(x-1, y+1, z-1);
                    break;
            }
            break;

        case YNEG:
            switch(i) {
                case 0:
                    side1 = getBlockAt(x-1, y-1, z);
                    side2 = getBlockAt(x, y-1, z-1);
                    corner = getBlockAt(x-1, y-1, z-1);
                    break;
                case 1:
                    side1 = getBlockAt(x+1, y-1, z);
                    side2 = getBlockAt(x, y-1, z-1);
                    corner = getBlockAt(x+1, y-1, z-1);
                    break;
                case 2:
                    side1 = getBlockAt(x+1, y-1, z);
                    side2 = getBlockAt(x, y-1, z+1);
                    corner = getBlockAt(x+1, y-1, z+1);
                    break;
                case 3:
                    side1 = getBlockAt(x-1, y-1, z);
                    side2 = getBlockAt(x, y-1, z+1);
                    corner = getBlockAt(x-1, y-1, z+1);
                    break;
            }
            break;

        case ZPOS:
            switch(i) {
                case 0:
                    side1 = getBlockAt(x-1, y, z+1);
                    side2 = getBlockAt(x, y-1, z+1);
                    corner = getBlockAt(x-1, y-1, z+1);
                    break;
                case 1:
                    side1 = getBlockAt(x+1, y, z+1);
                    side2 = getBlockAt(x, y-1, z+1);
                    corner = getBlockAt(x+1, y-1, z+1);
                    break;
                case 2:
                    side1 = getBlockAt(x+1, y, z+1);
                    side2 = getBlockAt(x, y+1, z+1);
                    corner = getBlockAt(x+1, y+1, z+1);
                    break;
                case 3:
                    side1 = getBlockAt(x-1, y, z+1);
                    side2 = getBlockAt(x, y+1, z+1);
                    corner = getBlockAt(x-1, y+1, z+1);
                    break;
            }
            break;

        case ZNEG:
            switch(i) {
                case 0:
                    side1 = getBlockAt(x+1, y, z-1);
                    side2 = getBlockAt(x, y-1, z-1);
                    corner = getBlockAt(x+1, y-1, z-1);
                    break;
                 case 1:
                    side1 = getBlockAt(x-1, y, z-1);
                    side2 = getBlockAt(x, y-1, z-1);
                    corner = getBlockAt(x-1, y-1, z-1);
                    break;
                case 2:
                    side1 = getBlockAt(x-1, y, z-1);
                    side2 = getBlockAt(x, y+1, z-1);
                    corner = getBlockAt(x-1, y+1, z-1);
                    break;
                case 3:
                    side1 = getBlockAt(x+1, y, z-1);
                    side2 = getBlockAt(x, y+1, z-1);
                    corner = getBlockAt(x+1, y+1, z-1);
                    break;
            }
            break;
    }

    return vertexAO(side1, side2, corner);
}

void Chunk::updateVBO(std::vector<glm::vec4> &interleave,
                      Direction dir, glm::vec4 pos,
                      BlockType blockType, int faces) {

    BlockNeighbor neighbor = neighbors.at(dir);
    glm::vec4 neighbor_uv = blockFaceUVs.at(blockType).at(dir);

    for (int i = 0; i < 4; i++) {
        glm::vec4 newPos = neighbor.vertices[i].pos + pos;
        interleave.push_back(newPos);
        interleave.push_back(glm::vec4(neighbor.offset, 1));

        if (blockType == LAVA || blockType == WATER) {
            neighbor_uv.z = 1;
        }

        glm::vec4 uv = glm::vec4(neighbor_uv + neighbor.vertices[i].uv);

        int aoValue = findAO(dir, pos - glm::vec4(minX, 0, minZ, 0), i);
        interleave.push_back(glm::vec4(uv[0], uv[1], 0, aoValue));
    }
}

// Does bounds checking with at()
void Chunk::setBlockAt(int x, int y, int z, BlockType t) {
    mutex.lock();

    m_blocks.at(x + 16 * y + 16 * 256 * z) = t;

    mutex.unlock();
}


const static std::unordered_map<Direction, Direction, EnumHash> oppositeDirection {
    {XPOS, XNEG},
    {XNEG, XPOS},
    {YPOS, YNEG},
    {YNEG, YPOS},
    {ZPOS, ZNEG},
    {ZNEG, ZPOS}
};

void Chunk::linkNeighbor(uPtr<Chunk> &neighbor, Direction dir) {

    if(neighbor != nullptr) {
        this->m_neighbors[dir] = neighbor.get();
        neighbor->m_neighbors[oppositeDirection.at(dir)] = this;
    }
}

int Chunk::getHeightAt(const int x, const int z) {
    for (int i = 255; i > 0; i--) {
        if (getBlockAt(x, i, z) != EMPTY) {
            return i;
        }
    }
    return 0;
}



