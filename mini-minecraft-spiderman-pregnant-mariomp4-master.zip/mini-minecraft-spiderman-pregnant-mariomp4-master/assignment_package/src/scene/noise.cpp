#include "noise.h"
#include <cmath>
#include <iostream>

Noise::Noise()
{}

float Noise::noise1d(float a, float b) {
    // taken from lecture slides
    glm::vec2 p = glm::vec2(a, b);
    return glm::fract(glm::sin(glm::dot(p,glm::vec2(127.1, 311.7))) * 43758.5453);
}

glm::vec2 Noise::noise2d(glm::vec2 p) {
    // modified from lecture slides
    return glm::fract(glm::sin(glm::vec2(glm::dot(p,glm::vec2(127.1, 311.7)) + 0.1438593f,
                                         glm::dot(p, glm::vec2(269.5, 183.3)) + 0.6437288f
                              )) * 43758.5453f);
}

glm::vec3 Noise::noise3d(glm::vec3 p) {
    // modified from lecture slides
    return glm::fract(glm::sin(glm::vec3(glm::dot(p, glm::vec3(127.1, 311.7, 147.3)) + 0.1438593f,
                                         glm::dot(p, glm::vec3(269.5, 183.3, 127.1)) + 0.6437288f,
                                         glm::dot(p, glm::vec3(149.5, 326.3, 432.7)) + 0.9465234f
                                         )) * 43758.5453f);
}

glm::vec3 Noise::noise3d2(glm::vec3 p) {
    // modified from lecture slides
    return glm::fract(glm::sin(glm::vec3(glm::dot(p, glm::vec3(259.5, 258.3, 194.1)) + 0.1438593f,
                                         glm::dot(p, glm::vec3(764.5, 562.3, 907.7)) + 0.6437288f,
                                         glm::dot(p, glm::vec3(423.5, 867.3, 452.7)) + 0.9465234f
                                         )) * 43758.5453f);
}

float Noise::interpNoise2D(float x, float y) {
    // taken from lecture slides
    int intX = int(floor(x));
    float fractX = glm::fract(x);
    int intY = int(floor(y));
    float fractY = glm::fract(y);

    float v1 = noise1d(intX, intY);
    float v2 = noise1d(intX + 1, intY);
    float v3 = noise1d(intX, intY + 1);
    float v4 = noise1d(intX + 1, intY + 1);
//    fractX = fractX * fractX * fractX * (fractX * (fractX * 6 + 15) - 10);
//    fractY = fractY * fractY * fractY * (fractY * (fractY * 6 + 15) - 10);

    float i1 = mix(v1, v2, fractX);
    float i2 = mix(v3, v4, fractX);

    return mix(i1, i2, fractY);
}

float Noise::mix(float a, float b, float val) {
    // LERPs between two values. Undefined behavior if val < 0 or val > 1
    return (a * (1 - val)) + (b * val);
}

float Noise::fbm(float x, float y, float H, float freq, float a) {
    // taken from iq
    float G = std::exp2(-H);
    float t = 0.0;
    int numOctaves = 8;
    for( int i=0; i<numOctaves; i++ )
    {
        t += a*interpNoise2D(freq*x, freq*y);
        freq *= 2.0;
        a *= G;
    }
    return t;
}

float Noise::domainWarpFbm(float x, float y, float H, float freq, float a) {
    float qx = fbm( x, y, H, freq, a);
    float qy = fbm( x + 5.2, y + 1.3, H, freq, a);

    return fbm( x + 40.0 * qx, y + 40.0 * qy, H, freq, a);
}

float Noise::perlinNoise2D(glm::vec2 uv) {
    // from lecture slides
    float surfletSum = 0.f;
    // Iterate over the four integer corners surrounding uv
    for(int dx = 0; dx <= 1; ++dx) {
        for(int dy = 0; dy <= 1; ++dy) {
            surfletSum += surflet2D(uv, glm::floor(uv) + glm::vec2(dx, dy));
        }
    }
    return surfletSum;
}

float Noise::perlinNoise3D(glm::vec3 p, bool noise) {
    //also from lecture slides
    float surfletSum = 0.f;
    // Iterate over the four integer corners surrounding uv
    for(int dx = 0; dx <= 1; ++dx) {
        for(int dy = 0; dy <= 1; ++dy) {
            for(int dz = 0; dz <= 1; ++dz) {
                surfletSum += surflet3D(p, glm::floor(p) + glm::vec3(dx, dy, dz), noise);
            }
        }
    }
    return surfletSum;
}

float Noise::surflet2D(glm::vec2 P, glm::vec2 gridPoint) {
    // from lecture slides
    // Compute falloff function by converting linear distance to a polynomial
    glm::vec2 diff = P - gridPoint;
    float distX = diff.x;
    float distY = diff.y;

    // Check if distX and distY are zero or one
//    std::cout << "distX: " << distX << ", distY: " << distY << std::endl;

    // Compute falloff function
    float tX = 1 - 6 * pow(abs(distX), 5.f) + 15 * pow(abs(distX), 4.f) - 10 * pow(abs(distX), 3.f);
    float tY = 1 - 6 * pow(abs(distY), 5.f) + 15 * pow(abs(distY), 4.f) - 10 * pow(abs(distY), 3.f);

    // Get the random vector for the grid point
    glm::vec2 gradient = 2.f * noise2d(gridPoint) - glm::vec2(1.f);

    // Get the value of our height field by dotting grid->P with our gradient
    float height = glm::dot(diff, gradient);

    // Scale our height field by our polynomial falloff function
    return height * tX * tY;
}

float Noise::surflet3D(glm::vec3 p, glm::vec3 gridPoint, bool noise) {
    // Compute the distance between p and the grid point along each axis, and warp it with a
    // quintic function so we can smooth our cells
    glm::vec3 t2 = glm::abs(p - gridPoint);
    float distX = t2.x;
    float distY = t2.y;
    float distZ = t2.z;

    float tX = 1.f - 6.f * pow(distX, 5.f) + 15.f * pow(distX, 4.f) - 10.f * pow(distX, 3.f);
    float tY = 1.f - 6.f * pow(distY, 5.f) + 15.f * pow(distY, 4.f) - 10.f * pow(distY, 3.f);
    float tZ = 1.f - 6.f * pow(distZ, 5.f) + 15.f * pow(distZ, 4.f) - 10.f * pow(distZ, 3.f);

    // Get the random vector for the grid point (assume we wrote a function random2
    // that returns a vec2 in the range [0, 1])
    glm::vec3 gradient;

    if (noise) {
        gradient = 2.f * noise3d(gridPoint) - glm::vec3(1., 1., 1.);
    } else {
        gradient = 2.f * noise3d2(gridPoint) - glm::vec3(1., 1., 1.);
    }

    // Get the vector from the grid point to P
    glm::vec3 diff = p - gridPoint;
    // Get the value of our height field by dotting grid->P with our gradient
    float height = glm::dot(diff, gradient);
    // Scale our height field (i.e. reduce it) by our polynomial falloff function
    return height * tX * tY * tZ;

}

glm::vec2 Noise::noise2dv2(glm::vec2 p) {
    float s = (float)((int)(p.x + p.y) % 2) * 2.f - 1.f;
    s *= 4.f;
    glm::vec2 k = glm::vec2(.3183f, .3678f);
    p = p * k + glm::vec2(k[1], k[0]) + 5.f;

    glm::vec4 v = glm::cos(glm::vec4(s) + glm::vec4(0,33,11,0));

    return (-1.f + 2.f * glm::fract(16.f * k * glm::fract(p.x * p.y * (p.x + p.y))))
           * glm::mat2(glm::vec2(v[0], v[1]), glm::vec2(v[2], v[3]));
}

float helper(float x, float y, glm::vec2 i, glm::vec2 f) {
    return glm::dot(Noise::noise2dv2(i + glm::vec2(x,y)), f - glm::vec2(x,y));
}

float Noise::noisev2(glm::vec2 p) {
    glm::vec2 i = glm::floor(p);
    glm::vec2 f = glm::fract(p);
    glm::vec2 u = f * f * (3.f - 2.f * f);

    return mix(mix(helper(0,0,i,f), helper(1,0,i,f), u.x),
               mix(helper(0,1,i,f), helper(1,1,i,f), u.x), u.y);
}

float Noise::perlin2dv2(glm::vec2& p)  //fractal noise
{
    glm::mat2 m = glm::mat2(glm::vec2(1.6, 1.2), glm::vec2(-1.2, 1.6));
    float v = 0.f;
    float s = 1.f;

    for(int i = 0; i < 4; i++, s /= 2.f) {
        v += s * noisev2(p);
        p = p * m;
    }
    return v;
}

float Noise::noise1d2(float a) {
    return glm::fract(glm::sin(a * 311.7)) * 43758.5453;
}

float Noise::interpNoise1D(float x) {
    //modified from lecture slides
    int intX = int(floor(x));
    float fractX = glm::fract(x);

    float v1 = noise1d2(intX);
    float v2 = noise1d2(intX + 1);

    return glm::mix(v1, v2, fractX);
}

float Noise::fbm2(float x) {
    //slightly modified iq stuff
    float a = 0.5;
    float freq = 4.0;
    int numOctaves = 8;
    float t = 0.0;
    for(int i = 0; i < numOctaves; i++) {
        t += interpNoise1D(freq * x) * a;
        a *= 0.5;
        freq *= 1.0;
    }
    return t;
}
